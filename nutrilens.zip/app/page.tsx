'use client';

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Camera, 
  History, 
  User, 
  Home, 
  Scan, 
  ArrowRight, 
  Info, 
  X, 
  Zap, 
  Star, 
  ChefHat, 
  Activity, 
  Flame, 
  Droplets, 
  Leaf, 
  CheckCircle2,
  LogOut,
  LogIn,
  Loader2
} from 'lucide-react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { auth, db, googleProvider, signInWithPopup, signOut } from '@/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp, Timestamp } from 'firebase/firestore';
import Image from 'next/image';
import Markdown from 'react-markdown';

// --- Types ---
interface NutritionData {
  calories: string;
  protein: string;
  carbs: string;
  fat: string;
}

interface AnalysisResult {
  foodName: string;
  description: string;
  ingredients: string[];
  nutrition: NutritionData;
  recipe: string[];
  healthTip: string;
}

interface ScanHistoryItem extends AnalysisResult {
  id: string;
  userId: string;
  imageUrl: string;
  timestamp: Timestamp;
}

// --- Components ---

const Navbar = ({ user, onSignOut }: { user: FirebaseUser | null, onSignOut: () => void }) => (
  <header className="fixed top-0 w-full z-50 bg-white/70 backdrop-blur-xl border-b border-black/5">
    <div className="flex justify-between items-center px-6 h-16 w-full max-w-screen-xl mx-auto">
      <div className="flex items-center gap-3">
        {user ? (
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-primary/10">
            <Image 
              src={user.photoURL || "https://picsum.photos/seed/user/100/100"} 
              alt="Profile" 
              width={40} 
              height={40} 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        ) : (
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <User size={20} />
          </div>
        )}
      </div>
      <div className="font-headline font-black text-2xl bg-gradient-to-br from-primary to-primary-container bg-clip-text text-transparent">
        NutriLens
      </div>
      <div className="flex items-center gap-2">
        {user ? (
          <button onClick={onSignOut} className="p-2 text-on-surface-variant hover:bg-surface-container rounded-full transition-colors">
            <LogOut size={20} />
          </button>
        ) : (
          <button className="p-2 text-primary">
            <LogIn size={20} />
          </button>
        )}
      </div>
    </div>
  </header>
);

const BottomNav = ({ activeTab, setActiveTab }: { activeTab: string, setActiveTab: (tab: string) => void }) => (
  <nav className="fixed bottom-6 left-0 right-0 z-50 flex justify-center px-4">
    <div className="bg-white/80 backdrop-blur-2xl w-full max-w-md rounded-[32px] shadow-[0_20px_40px_rgba(0,0,0,0.08)] border border-black/5 flex justify-around items-center px-4 py-3 h-20">
      {[
        { id: 'home', icon: Home },
        { id: 'scan', icon: Scan, primary: true },
        { id: 'history', icon: History },
        { id: 'profile', icon: User },
      ].map((item) => (
        <button
          key={item.id}
          onClick={() => setActiveTab(item.id)}
          className={`flex items-center justify-center rounded-full transition-all duration-300 ${
            item.primary 
              ? 'bg-gradient-to-tr from-primary to-primary-container text-white w-14 h-14 shadow-lg shadow-primary/30 active:scale-90' 
              : `w-12 h-12 active:scale-90 ${activeTab === item.id ? 'text-primary' : 'text-slate-400'}`
          }`}
        >
          <item.icon size={item.primary ? 28 : 24} fill={activeTab === item.id && !item.primary ? "currentColor" : "none"} />
        </button>
      ))}
    </div>
  </nav>
);

// --- Main App ---

export default function NutriLensApp() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [step, setStep] = useState<'home' | 'camera' | 'processing' | 'result'>('home');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // --- Auth ---
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Sign in error:", error);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setActiveTab('home');
      setStep('home');
    } catch (error) {
      console.error("Sign out error:", error);
    }
  };

  // --- History ---
  useEffect(() => {
    if (!user) {
      setHistory([]);
      return;
    }
    const q = query(
      collection(db, 'scans'),
      where('userId', '==', user.uid),
      orderBy('timestamp', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ScanHistoryItem));
      setHistory(items);
    });
    return () => unsubscribe();
  }, [user]);

  // --- Camera ---
  const startCamera = async () => {
    setStep('camera');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera error:", err);
      alert("Please allow camera access to scan food.");
      setStep('home');
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setCapturedImage(dataUrl);
        stopCamera();
        analyzeImage(dataUrl);
      }
    }
  };

  // --- AI Analysis ---
  const analyzeImage = async (base64Image: string) => {
    setStep('processing');
    setIsAnalyzing(true);

    try {
      const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (!apiKey) throw new Error("Gemini API key missing");

      const ai = new GoogleGenAI({ apiKey });

      const prompt = `
        Analyze this food image and provide a detailed report in JSON format.
        Include:
        - foodName: The name of the dish.
        - description: A short, appetizing description.
        - ingredients: A list of key ingredients.
        - nutrition: An object with calories, protein, carbs, and fat (as strings with units).
        - recipe: A step-by-step list of preparation instructions.
        - healthTip: A short AI-generated health insight about this meal.
        
        Return ONLY the JSON object.
      `;

      const imagePart = {
        inlineData: {
          data: base64Image.split(',')[1],
          mimeType: "image/jpeg",
        },
      };

      const result = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: [{ parts: [{ text: prompt }, imagePart] }],
        config: { responseMimeType: "application/json" }
      });

      const text = result.text;
      if (!text) throw new Error("No response from AI");
      const parsedData: AnalysisResult = JSON.parse(text);

      setAnalysisResult(parsedData);
      setStep('result');

      // Save to history if logged in
      if (user) {
        await addDoc(collection(db, 'scans'), {
          userId: user.uid,
          ...parsedData,
          imageUrl: base64Image,
          timestamp: serverTimestamp(),
        });
      }
    } catch (error) {
      console.error("Analysis error:", error);
      alert("Failed to analyze image. Please try again.");
      setStep('home');
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <Loader2 className="animate-spin text-primary" size={48} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen flex flex-col items-center justify-center px-6 text-center space-y-8 bg-background">
        <div className="relative w-32 h-32">
          <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full animate-pulse"></div>
          <div className="relative w-full h-full bg-gradient-to-tr from-primary to-primary-container rounded-3xl flex items-center justify-center text-white shadow-2xl">
            <Scan size={64} />
          </div>
        </div>
        <div className="space-y-4">
          <h1 className="font-headline font-black text-5xl tracking-tight">NutriLens</h1>
          <p className="text-on-surface-variant max-w-xs mx-auto">
            Scan your food, track nutrition, and discover recipes with AI.
          </p>
        </div>
        <button 
          onClick={handleSignIn}
          className="w-full max-w-xs h-16 bg-white border-2 border-primary/10 rounded-full flex items-center justify-center gap-4 font-headline font-bold text-lg shadow-xl active:scale-95 transition-all"
        >
          <Image src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/layout/google.svg" alt="Google" width={24} height={24} />
          Sign in with Google
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-32">
      <Navbar user={user} onSignOut={handleSignOut} />

      <main className="pt-24 px-6 max-w-screen-xl mx-auto">
        <AnimatePresence mode="wait">
          {step === 'home' && (
            <motion.div 
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-10"
            >
              <section>
                <h1 className="font-headline font-extrabold text-3xl tracking-tight">
                  Good Evening, {user.displayName?.split(' ')[0]} 👋
                </h1>
                <p className="text-on-surface-variant mt-1 font-medium">Ready to track your meal?</p>
              </section>

              <section className="relative py-8 overflow-hidden">
                <div className="flex flex-col items-center text-center space-y-6 relative z-10">
                  <h2 className="font-headline font-black text-5xl md:text-6xl tracking-tighter max-w-xs leading-[0.9]">
                    Scan Your <span className="text-primary italic">Food</span> 🍽️
                  </h2>
                  <div className="relative group mt-4">
                    <div className="absolute inset-0 bg-primary/30 blur-3xl rounded-full group-hover:bg-primary/50 transition-all duration-500"></div>
                    <button 
                      onClick={startCamera}
                      className="relative w-24 h-24 flex items-center justify-center rounded-full bg-gradient-to-tr from-primary to-primary-container text-white shadow-2xl shadow-primary/40 active:scale-90 transition-transform duration-300"
                    >
                      <Camera size={40} />
                    </button>
                  </div>
                </div>
              </section>

              <section className="space-y-4">
                <div className="flex justify-between items-end">
                  <h3 className="font-headline font-bold text-xl tracking-tight">Today&apos;s Balance</h3>
                  <span className="text-primary text-sm font-bold">View Details</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white p-6 rounded-3xl shadow-sm border border-black/5 flex flex-col justify-between min-h-[160px]">
                    <div className="flex justify-between items-start">
                      <span className="text-on-surface-variant font-bold text-xs uppercase tracking-widest">Calories</span>
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                        <Zap size={16} />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-4xl font-headline font-black">1,420</span>
                        <span className="text-on-surface-variant font-medium text-sm">/ 2,200 kcal</span>
                      </div>
                      <div className="w-full bg-surface-container h-2 rounded-full mt-4 overflow-hidden">
                        <div className="bg-gradient-to-r from-primary to-primary-container h-full w-[64%] rounded-full"></div>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-3xl border border-black/5 flex flex-col justify-between">
                      <span className="text-on-surface-variant font-bold text-[10px] uppercase tracking-widest">Protein</span>
                      <div className="mt-2">
                        <span className="text-xl font-headline font-bold">84g</span>
                        <div className="w-full bg-secondary/10 h-1.5 rounded-full mt-2">
                          <div className="bg-secondary h-full w-[80%] rounded-full"></div>
                        </div>
                      </div>
                    </div>
                    <div className="bg-white p-4 rounded-3xl border border-black/5 flex flex-col justify-between">
                      <span className="text-on-surface-variant font-bold text-[10px] uppercase tracking-widest">Carbs</span>
                      <div className="mt-2">
                        <span className="text-xl font-headline font-bold">120g</span>
                        <div className="w-full bg-orange-100 h-1.5 rounded-full mt-2">
                          <div className="bg-orange-500 h-full w-[45%] rounded-full"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {history.length > 0 && (
                <section className="space-y-4">
                  <div className="flex justify-between items-end">
                    <h3 className="font-headline font-bold text-xl tracking-tight">Recent Scans</h3>
                    <button onClick={() => setActiveTab('history')} className="text-on-surface-variant text-sm">See all</button>
                  </div>
                  <div className="flex overflow-x-auto gap-5 pb-4 hide-scrollbar -mx-6 px-6">
                    {history.slice(0, 5).map((item) => (
                      <div 
                        key={item.id} 
                        className="flex-none w-48 group cursor-pointer"
                        onClick={() => {
                          setAnalysisResult(item);
                          setCapturedImage(item.imageUrl);
                          setStep('result');
                        }}
                      >
                        <div className="relative w-48 h-56 rounded-3xl overflow-hidden mb-3 bg-surface-container-low transition-transform duration-300 group-hover:scale-[0.98]">
                          <Image 
                            src={item.imageUrl} 
                            alt={item.foodName} 
                            fill 
                            className="object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur shadow-sm px-2 py-1 rounded-full flex items-center gap-1">
                            <Star size={12} className="text-yellow-500 fill-yellow-500" />
                            <span className="text-[10px] font-bold">AI Verified</span>
                          </div>
                        </div>
                        <h4 className="font-headline font-bold truncate">{item.foodName}</h4>
                        <p className="text-on-surface-variant text-xs font-medium">{item.nutrition.calories} kcal</p>
                      </div>
                    ))}
                  </div>
                </section>
              )}
            </motion.div>
          )}

          {step === 'camera' && (
            <motion.div 
              key="camera"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black"
            >
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                className="w-full h-full object-cover"
              />
              <canvas ref={canvasRef} className="hidden" />
              
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-72 h-72 border-2 border-white/30 rounded-[40px] relative">
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-2xl"></div>
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-2xl"></div>
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-2xl"></div>
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-2xl"></div>
                  <motion.div 
                    animate={{ top: ['0%', '100%', '0%'] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent shadow-[0_0_15px_rgba(99,14,212,0.8)]"
                  />
                </div>
              </div>

              <div className="absolute top-0 w-full p-6 flex justify-between items-center bg-gradient-to-b from-black/60 to-transparent">
                <button onClick={() => { stopCamera(); setStep('home'); }} className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white">
                  <X size={24} />
                </button>
                <div className="px-4 py-2 bg-white/10 backdrop-blur-md rounded-full text-white text-xs font-bold tracking-widest uppercase">
                  Detecting Food...
                </div>
              </div>

              <div className="absolute bottom-12 w-full px-12 flex justify-center items-center">
                <button 
                  onClick={capturePhoto}
                  className="w-20 h-20 rounded-full bg-white border-8 border-white/20 flex items-center justify-center shadow-2xl active:scale-90 transition-transform"
                >
                  <div className="w-14 h-14 rounded-full bg-primary"></div>
                </button>
              </div>
            </motion.div>
          )}

          {step === 'processing' && (
            <motion.div 
              key="processing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-background flex flex-col items-center justify-center px-6"
            >
              <div className="relative w-64 h-64 mb-12 flex items-center justify-center">
                <motion.div 
                  animate={{ scale: [0.8, 1.2, 0.8], opacity: [0.5, 0.2, 0.5] }}
                  transition={{ duration: 3, repeat: Infinity }}
                  className="absolute inset-0 rounded-full border-2 border-primary/20"
                />
                <div className="relative w-40 h-40 rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
                  {capturedImage && (
                    <Image src={capturedImage} alt="Captured" fill className="object-cover" />
                  )}
                  <motion.div 
                    animate={{ top: ['-100%', '400%'] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/40 to-transparent h-1/4 w-full"
                  />
                </div>
              </div>
              <div className="text-center space-y-4">
                <h1 className="font-headline font-bold text-2xl tracking-tight">Analyzing your food...</h1>
                <div className="flex justify-center gap-2">
                  <motion.span animate={{ y: [0, -10, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0 }} className="w-2 h-2 bg-primary rounded-full" />
                  <motion.span animate={{ y: [0, -10, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }} className="w-2 h-2 bg-primary rounded-full" />
                  <motion.span animate={{ y: [0, -10, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }} className="w-2 h-2 bg-primary rounded-full" />
                </div>
                <p className="text-on-surface-variant max-w-[280px] mx-auto text-sm opacity-80">
                  Identifying ingredients and calculating nutritional density using <span className="font-bold text-primary">NutriLens AI</span>
                </p>
              </div>
            </motion.div>
          )}

          {step === 'result' && analysisResult && (
            <motion.div 
              key="result"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8 pb-12"
            >
              <div className="relative -mx-6 h-[400px] overflow-hidden">
                {capturedImage && (
                  <Image src={capturedImage} alt="Food" fill className="object-cover" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
                <button 
                  onClick={() => setStep('home')}
                  className="absolute top-6 left-6 p-3 bg-white/20 backdrop-blur-md rounded-full text-white"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="-mt-16 relative z-10 space-y-6">
                <div className="inline-flex items-center px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-bold">
                  <CheckCircle2 size={14} className="mr-1" />
                  AI ANALYSIS COMPLETE
                </div>
                <h1 className="text-4xl font-headline font-extrabold tracking-tight">{analysisResult.foodName}</h1>
                <p className="text-on-surface-variant font-medium text-lg leading-relaxed">
                  {analysisResult.description}
                </p>
              </div>

              <section className="bg-white rounded-3xl p-8 shadow-sm border border-black/5">
                <h2 className="text-2xl font-headline font-bold mb-8">Nutrition Overview</h2>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
                  {[
                    { label: 'Protein', value: analysisResult.nutrition.protein, color: 'bg-primary', width: '85%' },
                    { label: 'Calories', value: analysisResult.nutrition.calories, color: 'bg-secondary', width: '60%' },
                    { label: 'Carbs', value: analysisResult.nutrition.carbs, color: 'bg-orange-500', width: '25%' },
                    { label: 'Fats', value: analysisResult.nutrition.fat, color: 'bg-cyan-500', width: '45%' },
                  ].map((item) => (
                    <div key={item.label} className="flex flex-col gap-2">
                      <div className="flex justify-between items-end">
                        <span className="text-sm font-bold text-on-surface-variant uppercase tracking-wider">{item.label}</span>
                        <span className="text-xl font-headline font-extrabold">{item.value}</span>
                      </div>
                      <div className="h-3 w-full bg-surface-container rounded-full overflow-hidden">
                        <div className={`h-full ${item.color} rounded-full`} style={{ width: item.width }}></div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-surface-container-low rounded-3xl p-8 space-y-6">
                  <h2 className="text-2xl font-headline font-bold">Key Ingredients</h2>
                  <div className="flex flex-wrap gap-2">
                    {analysisResult.ingredients.map((ing) => (
                      <span key={ing} className="px-4 py-2 bg-primary/10 text-primary font-semibold rounded-full text-sm">
                        {ing}
                      </span>
                    ))}
                  </div>
                  <div className="p-4 bg-white rounded-2xl border border-black/5">
                    <p className="text-xs font-bold text-secondary uppercase tracking-widest mb-1">AI Health Tip</p>
                    <p className="text-sm text-on-surface-variant italic">&quot;{analysisResult.healthTip}&quot;</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <h2 className="text-2xl font-headline font-bold">Preparation Steps</h2>
                  <div className="space-y-4">
                    {analysisResult.recipe.map((step, idx) => (
                      <div key={idx} className="bg-white p-6 rounded-2xl border-l-4 border-primary shadow-sm flex gap-6">
                        <span className="text-4xl font-headline font-black text-primary/20">{(idx + 1).toString().padStart(2, '0')}</span>
                        <p className="text-on-surface-variant leading-relaxed text-sm">{step}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            </motion.div>
          )}
        </AnimatePresence>

        {activeTab === 'history' && step === 'home' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            <h2 className="text-2xl font-headline font-bold">Scan History</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {history.map((item) => (
                <div 
                  key={item.id}
                  onClick={() => {
                    setAnalysisResult(item);
                    setCapturedImage(item.imageUrl);
                    setStep('result');
                  }}
                  className="bg-white rounded-3xl overflow-hidden border border-black/5 shadow-sm group cursor-pointer hover:shadow-md transition-all"
                >
                  <div className="relative h-48">
                    <Image src={item.imageUrl} alt={item.foodName} fill className="object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="p-6">
                    <h3 className="font-headline font-bold text-lg">{item.foodName}</h3>
                    <p className="text-on-surface-variant text-sm">{item.nutrition.calories} kcal • {new Date(item.timestamp?.toDate()).toLocaleDateString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'profile' && step === 'home' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center py-12 space-y-8"
          >
            <div className="relative">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-primary/20">
                <Image 
                  src={user.photoURL || "https://picsum.photos/seed/user/200/200"} 
                  alt="Profile" 
                  width={128} 
                  height={128} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute bottom-0 right-0 bg-primary text-white p-2 rounded-full border-4 border-background">
                <Star size={16} fill="currentColor" />
              </div>
            </div>
            <div className="text-center">
              <h2 className="text-3xl font-headline font-extrabold">{user.displayName}</h2>
              <p className="text-on-surface-variant">{user.email}</p>
            </div>
            <div className="grid grid-cols-3 gap-4 w-full max-w-md">
              <div className="bg-surface-container-low p-4 rounded-3xl text-center">
                <p className="text-2xl font-headline font-black text-primary">{history.length}</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant">Scans</p>
              </div>
              <div className="bg-surface-container-low p-4 rounded-3xl text-center">
                <p className="text-2xl font-headline font-black text-secondary">12</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant">Streak</p>
              </div>
              <div className="bg-surface-container-low p-4 rounded-3xl text-center">
                <p className="text-2xl font-headline font-black text-orange-500">Gold</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant">Tier</p>
              </div>
            </div>
            <button 
              onClick={handleSignOut}
              className="px-8 py-4 bg-error/10 text-error font-headline font-bold rounded-full flex items-center gap-2 hover:bg-error/20 transition-all"
            >
              <LogOut size={20} />
              Sign Out
            </button>
          </motion.div>
        )}
      </main>

      {step === 'home' && (
        <BottomNav activeTab={activeTab} setActiveTab={(tab) => {
          if (tab === 'scan') startCamera();
          else setActiveTab(tab);
        }} />
      )}
    </div>
  );
}
